#include <stdio.h>
#include <stdlib.h>
#include "stat.h"
#include <string.h>
float TVB(char* filename)
{
 float taux;
 int nbr_vote=0;
 int nbr_voteB=0;
 utilisateur u;
 FILE * f=fopen(filename, "r");
 if(f!=NULL)
  { while (fscanf(f,"%s %s %s %d %s %d %d %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.Age,u.Adresse,&u.tel,&u.Role,&u.id_bv,&u.Vote)!=EOF)
       {
           if ((u.Vote!=-1)&&(u.Role==3))
                nbr_vote++;
           if ((u.Vote==0)&&(u.Role==3))
                nbr_voteB++; } }

taux=(float) nbr_voteB*100/nbr_vote;
fclose(f);
return taux; }


int nbr_e(char* filename,int id)
{ int nbe=0;
  utilisateur u;
  FILE * f=fopen(filename, "r");
	printf("%d",u.Role);
   if(f!=NULL)
  { while (fscanf(f,"%s %s %s %d %s %d %d %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.Age,u.Adresse,&u.tel,&u.Role,&u.id_bv,&u.Vote)!=EOF)
     { 
         if((id==u.id_bv)&&(u.Role==3))
            nbe++; }
   fclose(f); }
   return nbe;
 }


