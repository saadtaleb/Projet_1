#ifndef BV_H_INCLUDED
#define BV_H_INCLUDED
#include <stdio.h>
//#include <gtk/gtk.h>
typedef struct
{   int ID_Bv;
    int capacite_elec;
    int capacite_obs;
    char addresse[20];
    int salle;
    int id_agent; }BureauVote;

int ajouter(char * , BureauVote );
int modifier(char * , int , BureauVote);
int supprimer(char * , int );
BureauVote chercher(char * , int );


#endif // BV_H_INCLUDED

