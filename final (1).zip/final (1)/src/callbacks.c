#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "BV.h"
#include "stat.h" 
int T[3]={0,0,0};
int reponse;

void
on_retour_bv_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestionbv , * window_ajouter_bv ;

window_ajouter_bv = lookup_widget(button,"window_ajouter_bv");

  gtk_widget_hide (window_ajouter_bv);
  window_gestionbv = create_window_gestionbv();
  gtk_widget_show (window_gestionbv);}


void
on_ajouter_bv_clicked                  (GtkWidget       *objet,
                                        gpointer        user_data)
{	int v,x ;
	char f[50];
	BureauVote b,s ;
	GtkWidget *input1, *input2 ,*spinbutton11,*spinbutton9,*spinbutton5,*spinbutton14,*sortie;
	GtkWidget *window_ajouter_bv;
	GtkWidget *window_confirm_ajout_bureau;
	window_ajouter_bv = lookup_widget(objet,"window_ajouter_bv");
	
	//les 3 chars ==> id / nbre_habitant/date
	input1 = lookup_widget(objet,"entry26");
	input2=lookup_widget(objet,"entry15");
	sortie=lookup_widget(objet,"label92");
	
	strcpy(b.addresse,gtk_entry_get_text(GTK_ENTRY(input1)));

	// id chaine en int
	strcpy(f,gtk_entry_get_text(GTK_ENTRY(input2)));
	v=atoi(f);
	b.id_agent=v;
	

	//spinbutton==>Conseillers
	spinbutton11=lookup_widget(objet,"spinbutton11");
	b.ID_Bv=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton11));
	spinbutton9=lookup_widget(objet,"spinbutton9");
	b.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton9));
	spinbutton5=lookup_widget(objet,"spinbutton5");
	b.capacite_obs=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton5));
	spinbutton14=lookup_widget(objet,"spinbutton14");
	b.capacite_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton14));
	
	
	
	x=ajouter("bv(1).txt", b);
	s=chercher("bv.txt",b.ID_Bv);

if (s.ID_Bv!=-1)
{gtk_label_set_text(GTK_LABEL(sortie),"id existant!");
		remove("bv(1).txt");
		return;
		}
else if ((b.addresse==NULL)||(b.id_agent==0))
	{gtk_label_set_text(GTK_LABEL(sortie),"il faut remplir tous les champs");
		remove("bv(1).txt");
		return;} 
else if (verif("bv.txt",b)==0) 
{gtk_label_set_text(GTK_LABEL(sortie),"un tels bureau existe");
		remove("bv(1).txt");
		return;} 
else {
	if ((x==1)&&(reponse==1))
		{window_ajouter_bv=lookup_widget(objet, "window_ajouter_bv");
		gtk_widget_hide(window_ajouter_bv);
		window_confirm_ajout_bureau = create_window_confirm_ajout_bureau();
		gtk_widget_show (window_confirm_ajout_bureau);}
	else if ((x==1)&&(reponse==2)) 
			{return;
			remove("bv(1).txt");}
else if (x==0) 	
{gtk_label_set_text(GTK_LABEL(sortie),"echec d'ajout");
		remove("bv(1).txt");
		return;} 
}	}		 

void
on_button_confirmer_ajout_clicked      (GtkButton       *button,
                                        gpointer         user_data)

{BureauVote bv;
int x=0;
GtkWidget *window_ajouter_bv;
GtkWidget *window_confirm_ajout_bureau;
GtkWidget *sortie;
window_confirm_ajout_bureau = lookup_widget(button, "window_confirm_ajout_bureau");
sortie=lookup_widget(button,"label92");
FILE * f=fopen("bv(1).txt", "r");
    if(f!=NULL)
	{fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec,&bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent);
		fclose(f);
		remove("bv(1).txt"); 
		x=ajouter("bv.txt",bv); 
		if (x==1)		
	
gtk_widget_hide(window_confirm_ajout_bureau);
window_ajouter_bv = create_window_ajouter_bv();
gtk_widget_show (window_ajouter_bv);
gtk_label_set_text(GTK_LABEL(sortie),"ajout avec succes "); }}


void
on_annuler_bv_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter_bv;
GtkWidget *window_confirm_ajout_bureau;

FILE * f=fopen("bv(1).txt", "r");
    if(f!=NULL)
	{
		fclose(f);
		remove("bv(1).txt");}		
window_confirm_ajout_bureau = lookup_widget(button, "window_confirm_ajout_bureau");	
gtk_widget_hide(window_confirm_ajout_bureau);
window_ajouter_bv = create_window_ajouter_bv();
gtk_widget_show (window_ajouter_bv);
}


void
on_aller_supprimer_bv_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
	{int v,x ;
	char f[50];
	BureauVote b ;
	GtkWidget *input1 ,*sortie;
	
	//les 3 chars ==> id / nbre_habitant/date
	input1 = lookup_widget(objet,"entry31");
	sortie=lookup_widget(objet,"label200");

	// id chaine en int
	strcpy(f,gtk_entry_get_text(GTK_ENTRY(input1)));
	v=atoi(f);
	b.ID_Bv=v;
	

	
	
	
	x=supprimer("bv.txt", b.ID_Bv);
	if (x==1)
		gtk_label_set_text(GTK_LABEL(sortie),"suppression avec succes ");
	else 
		gtk_label_set_text(GTK_LABEL(sortie),"id introuvable"); }


void
on_aller_afficher_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestionbv , *window_afficherbv,*treeview1_bv ;

window_gestionbv = lookup_widget(button,"window_gestionbv");

  gtk_widget_hide (window_gestionbv);
window_afficherbv=lookup_widget(GTK_WIDGET(button),"window_afficherbv");
  window_afficherbv = create_window_afficherbv();


treeview1
  gtk_widget_show (window_afficherbv);
  treeview1_bv=lookup_widget(window_afficherbv,"treeview1_bv");

  afficher_BureauVote(treeview1_bv);
}


void
on_aller_modifier_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestionbv , *window_modifier_bv ;

window_gestionbv = lookup_widget(button,"window_gestionbv");

  gtk_widget_hide (window_gestionbv);
  window_modifier_bv = create_window_modifier_bv();
  gtk_widget_show (window_modifier_bv);
}



void
on_aller_ajouter_bv_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter_bv;
GtkWidget *window_gestionbv;
  window_gestionbv = lookup_widget(button, "window_gestionbv");
  gtk_widget_hide (window_gestionbv);
  window_ajouter_bv = create_window_ajouter_bv();
  gtk_widget_show (window_ajouter_bv);}





void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *id_bv, *addresse, *salle;
BureauVote test,bv;
char f[20]; 
	
	if (T[0]==1 && T[1]==0 && T[2]==0){
		id_bv=lookup_widget(GTK_WIDGET(button),"entry19");
		strcpy(f,gtk_entry_get_text(GTK_ENTRY(id_bv)));
		test.ID_Bv=atoi(f);
		FILE * f=fopen("bv.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF){
			if (test.ID_Bv==bv.ID_Bv){
				fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

liste=create_window_afficherbv();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1_bv");

affiche_BureauVote(treeview);

T[0]=0;

		}
	else if (T[1]==1 && T[0]==0 && T[2]==0){
		addresse=lookup_widget(GTK_WIDGET(button),"entry20");
		strcpy(test.addresse,gtk_entry_get_text(GTK_ENTRY(addresse)));
		FILE * f=fopen("bv.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while (fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF){
			if (strcmp(test.addresse,bv.addresse)==0){
				fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

liste=create_window_afficherbv();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1_bv");

affiche_BureauVote(treeview);

T[1]=0;
}

	else if (T[2]==1 && T[0]==0 && T[1]==0){
		salle=lookup_widget(GTK_WIDGET(button),"entry22");
		strcpy(f,gtk_entry_get_text(GTK_ENTRY(salle)));
		test.salle=atoi(f);
		FILE * f=fopen("bv.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF){
			if (test.salle==bv.salle){
				fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

liste=create_window_afficherbv();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1_bv");

affiche_BureauVote(treeview);

T[2]=0;

		}
else if (T[1]==1 && T[0]==1 && T[2]==0)
{id_bv=lookup_widget(GTK_WIDGET(button),"entry19");
		strcpy(f,gtk_entry_get_text(GTK_ENTRY(id_bv)));
		test.ID_Bv=atoi(f);
		FILE * f=fopen("bv.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		addresse=lookup_widget(GTK_WIDGET(button),"entry20");
		strcpy(test.addresse,gtk_entry_get_text(GTK_ENTRY(addresse)));
		while(fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF){
			if ((test.ID_Bv==bv.ID_Bv)&&(bv.addresse==addresse)){
				fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

liste=create_window_afficherbv();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1_bv");

affiche_BureauVote(treeview);
T[1]=0; 
T[0]=0;}

	else {
		GtkWidget *supprimer, *liste, *treeview ;

		supprimer=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

		gtk_widget_destroy(supprimer);

		liste=lookup_widget(GTK_WIDGET(button),"window_afficherbv");

		liste=create_window_afficherbv();

		gtk_widget_show(liste);

		treeview=lookup_widget(liste,"treeview1_bv");

		afficher_BureauVote(treeview);

		T[0]=0;

		T[1]=0;

		T[2]=0;

	}
}


void
on_numerobv_modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_modifbv_adresse_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_idagent_modifbv_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_modifbv_numerosalle_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_retour_gestion_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestionbv , *window_modifier_bv ;

window_modifier_bv = lookup_widget(button,"window_modifier_bv");

  gtk_widget_hide (window_modifier_bv);
  window_gestionbv = create_window_gestionbv();
  gtk_widget_show (window_gestionbv);
}



void
on_modif_bv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{	int v,x ;
	char f[50];
	BureauVote b ;
	GtkWidget *input1, *input2 ,*spinbutton20,*spinbutton19,*spinbutton23,*spinbutton22,*sortie;
	GtkWidget *window_ajouter_bv;
	window_ajouter_bv = create_window_ajouter_bv();
	
	//les 3 chars ==> id / nbre_habitant/date
	input1 = lookup_widget(objet,"entry29");
	input2=lookup_widget(objet,"entry30");
	sortie=lookup_widget(objet,"label90");
	
	strcpy(b.addresse,gtk_entry_get_text(GTK_ENTRY(input1)));

	// id chaine en int
	strcpy(f,gtk_entry_get_text(GTK_ENTRY(input2)));
	v=atoi(f);
	b.id_agent=v;
	

	//spinbutton==>Conseillers
	spinbutton23=lookup_widget(objet,"spinbutton23");
	b.ID_Bv=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton23));
	spinbutton20=lookup_widget(objet,"spinbutton20");
	b.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton20));
	spinbutton22=lookup_widget(objet,"spinbutton22");
	b.capacite_obs=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton22));
	spinbutton19=lookup_widget(objet,"spinbutton19");
	b.capacite_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton19));
if ((b.addresse==NULL)||(b.id_agent==0))
	{gtk_label_set_text(GTK_LABEL(sortie),"il faut remplir tous les champs");
		return;}
else if (verif("bv.txt",b)==0)
{gtk_label_set_text(GTK_LABEL(sortie),"Un tel bv existe");
		return;}
else {x=modifier("bv.txt",b.ID_Bv, b);
	if (x==1)
		{gtk_label_set_text(GTK_LABEL(sortie),"modification avec succes ");
			return;}
	else 
		{gtk_label_set_text(GTK_LABEL(sortie),"bureau introuvable"); 
	
			return;}			 
}}



void
on_refrech_bv_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window_afficherbv ,*w1;
	GtkWidget *treeview1_bv ; 


	w1 = lookup_widget(button,"window_afficherbv");
	window_afficherbv=create_window_afficherbv();

	gtk_widget_show(window_afficherbv);

	gtk_widget_hide (w1);
	treeview1_bv=lookup_widget(window_afficherbv,"treeview1_bv");

	/*vider(treeview1_bv);*/
	afficher_BureauVote(treeview1_bv);}


void
on_retour_affich_bv_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestionbv , * window_afficherbv ;

window_afficherbv = lookup_widget(button,"window_afficherbv");

  gtk_widget_hide (window_afficherbv);
  window_gestionbv = create_window_gestionbv();
  gtk_widget_show (window_gestionbv);}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		T[0]=1;
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		T[2]=1;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))		
		T[1]=1;
}









void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{ 
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  reponse=1;


}


void
on_non_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{ 
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  reponse=2;


}


void
on_taux_vb_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *sortie;
GtkWidget *window_gestionbv;

	char str[20] ;
	float x;
	sortie=lookup_widget(objet,"label199");
window_gestionbv = lookup_widget(objet,"window_gestionbv");
	x=TVB("utilisateur.txt"); 
sprintf(str, "%f" , x);


	gtk_label_set_text(GTK_LABEL(sortie),str  );
}


void
on_stat_bv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sortie;
GtkWidget *window_gestionbv,*spinbutton24_bv;

	char str[20] ;
	int x,id_bv;
spinbutton24_bv=lookup_widget(objet,"spinbutton24_bv");
	id_bv=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton24_bv));
	sortie=lookup_widget(objet,"label199");
window_gestionbv = lookup_widget(objet,"window_gestionbv");
	x=nbr_e("utilisateur.txt",id_bv); 
sprintf(str, "%d" , x);


	gtk_label_set_text(GTK_LABEL(sortie),str  );
}
