#include "reclame.h"
#include <stdio.h>
#include <string.h> 

#include <stdlib.h>
#include <gtk/gtk.h>
enum 
{
	EID,
	ENUML,
	ENUMB,
	EDATE,
	ETEXT,
	ETYPE,
	COLUMNS,
};
///////////////////////

int modifier_reclamation( char *filename, int id, reclame nouv )
{
    
    reclame r;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f==NULL || f2==NULL)
	return 0;
    else 
{
        while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau, r.date,r.texte,r.type_rec)!=EOF)
        {
		if(r.id!=id)
           	{
                fprintf(f2,"%d %d %d %s %s %s\n",r.id, r.num_list_elec, r.num_bureau, r.date, r.texte, r.type_rec);
		}	
            else
                fprintf(f2,"%d %d %d %s %s %s\n",nouv.id, nouv.num_list_elec, nouv.num_bureau, nouv.date, nouv.texte, nouv.type_rec);
    }}
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
   return 1;
}

/////////////////////////////////
void afficher_reclamation(GtkWidget *liste) 
{
	GtkCellRenderer * renderer; // afficheur de cellule (dans notre exemple contient du texte ) envoie de saisie de l'utilisateur pour ch aque champ
	GtkTreeViewColumn *column ; // visualisation des colonnes 
	GtkTreeIter iter ;

	GtkListStore *store ; // creadtion du modele de type liste 

	// des champs simulaire a ma structure 
	int id ;
    	int num_list_elec;
    	int num_bureau ;
    	char date[70] ;
   	char texte[300];
	char type_rec[200];
	
	
	
	store = NULL;

	FILE *f ;
	store = gtk_tree_view_get_model(liste);

	if(store==NULL)
	{

	renderer = gtk_cell_renderer_text_new(); // pour chaque colonne j'aurai besoin de faire 3 operation 1)stocke dans le pointeur renderer valeur retourner par methode gtk_cell_renderer
	column = gtk_tree_view_column_new_with_attributes("id",renderer , "text",EID , NULL ) ;// stocker l'attribut de chaque colonne
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column); // affecte se champs a un colonne bien definie de ma tree view 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("num_list_elec", renderer, "text" ,ENUML , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("num_bureau", renderer, "text" ,ENUMB , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("date", renderer, "text" ,EDATE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("texte", renderer, "text" , ETEXT, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type_rec", renderer, "text" , ETYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	}
	
	// la liste contient 6 colonnes 
	store = gtk_list_store_new (COLUMNS ,G_TYPE_INT ,G_TYPE_INT ,G_TYPE_INT ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING );
	



	//l'etape suivante est de recuperee les donées dans un fichier
	f = fopen("reclamation.txt","r");
	if(f==NULL) 
	{
		return ; 
	} 
	else //lecture des enregistrement pour le mettre dans ma treeview
	{
		f= fopen("reclamation.txt","a+");
		while(fscanf(f,"%d %d %d %s %s %s\n",&id ,&num_list_elec ,&num_bureau ,date ,texte ,type_rec)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store ,&iter ,EID ,id ,ENUML, num_list_elec, ENUMB ,num_bureau ,EDATE ,date ,ETEXT, texte ,ETYPE, type_rec, -1 );// correspondre chaque champs recupere a un variable enemurateur
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
}



//////////////////////////////////

void affiche_reclamation(GtkWidget *pliste)
{
	GtkCellRenderer *prenderer; // afficheur de cellule (dans notre exemple contient du texte ) envoie de saisie de l'utilisateur pour ch aque champ
	GtkTreeViewColumn *pcolumn ; // visualisation des colonnes 
	GtkTreeIter piter ;

	GtkListStore *pstore ; // creadtion du modele de type liste 

	// des champs simulaire a ma structure 
	int id ;
    	int num_list_elec;
    	int num_bureau ;
    	char date[70] ;
   	char texte[300];
	char type_rec[200];
	
	
	
	pstore = NULL;

	FILE *f ;
	pstore = gtk_tree_view_get_model(pliste);

	if(pstore==NULL)
	{

	prenderer = gtk_cell_renderer_text_new(); // pour chaque colonne j'aurai besoin de faire 3 operation 1)stocke dans le pointeur renderer valeur retourner par methode gtk_cell_renderer
	pcolumn = gtk_tree_view_column_new_with_attributes("id",prenderer , "text",EID , NULL ) ;// stocker l'attribut de chaque colonne
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn); // affecte se champs a un colonne bien definie de ma tree view 


	prenderer = gtk_cell_renderer_text_new();
	pcolumn = gtk_tree_view_column_new_with_attributes("num_list_elec", prenderer, "text" ,ENUML , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn);



	prenderer = gtk_cell_renderer_text_new();
	pcolumn = gtk_tree_view_column_new_with_attributes("num_bureau", prenderer, "text" ,ENUMB , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn);



	prenderer = gtk_cell_renderer_text_new();
	pcolumn = gtk_tree_view_column_new_with_attributes("date", prenderer, "text" ,EDATE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn);


	prenderer = gtk_cell_renderer_text_new();
	pcolumn = gtk_tree_view_column_new_with_attributes("texte", prenderer, "text" , ETEXT, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn);

	prenderer = gtk_cell_renderer_text_new();
	pcolumn = gtk_tree_view_column_new_with_attributes("type_rec", prenderer, "text" , ETYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pliste), pcolumn);


	}
	
	// la liste contient 6 colonnes 
	pstore = gtk_list_store_new (COLUMNS ,G_TYPE_INT ,G_TYPE_INT ,G_TYPE_INT ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING );
	



	//l'etape suivante est de recuperee les donées dans un fichier
	f = fopen("recherche.txt","r");
	if(f==NULL) 
	{
		return ; 
	} 
	else //lecture des enregistrement pour le mettre dans ma treeview
	{
		f= fopen("recherche.txt","a+");
		while(fscanf(f,"%d %d %d %s %s %s\n",&id ,&num_list_elec ,&num_bureau ,date ,texte ,type_rec)!=EOF)
		{
			gtk_list_store_append(pstore,&piter);
			gtk_list_store_set(pstore ,&piter ,EID ,id ,ENUML, num_list_elec, ENUMB ,num_bureau ,EDATE ,date ,ETEXT, texte ,ETYPE, type_rec, -1 );// correspondre chaque champs recupere a un variable enemurateur
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW (pliste), GTK_TREE_MODEL(pstore));
		g_object_unref(pstore);
	}

}
//////////////////////////////////////////////////

reclame chercher_reclamation(char * filename, int id)
{
    reclame r;
    int tr=0;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while((tr==0) && fscanf(f,"%d %d %d %s %s %s\n",&r.id, &r.num_list_elec, &r.num_bureau, r.date, r.texte, r.type_rec)!=EOF)
        {
            if(r.id== id)
                tr=1;
        }
    }
   
    if(tr==0)
        r.id=-1;
    return r;
}             
//////////////////////////////////////////////
int supprimer_reclamation(char * filename, int id)
{
    int tr=0;
    reclame r;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau, r.date, r.texte, r.type_rec)!=EOF)
        {
            if(r.id== id)
                tr=1;
            else
                fprintf(f2,"%d %d %d %s %s %s\n",r.id, r.num_list_elec, r.num_bureau, r.date, r.texte, r.type_rec);
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
}
//////////////////////////////////////////////
int ajouter_reclamation(char * filename, reclame r )
{
    FILE * f=fopen(filename, "a");
    if(f!=NULL)
    {
        fprintf(f,"%d %d %d %s %s %s\n",r.id, r.num_list_elec, r.num_bureau, r.date, r.texte, r.type_rec);
        fclose(f);
        return 1;
    }
    else return 0;
}
//////////////////////////////////
int nbr_rec()
{
int i=0;
reclame r;
FILE *f;
f= fopen("reclamation.txt","a+");
while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau, r.date,r.texte,r.type_rec)!=EOF)
{
i++;

}
fclose(f);
return i;
}
/////////////////////////////////
int nbr_rec_parlis(int numero_list)
{
int i=0;
reclame r;
FILE *f;
f= fopen("reclamation.txt","a+");
while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau, r.date,r.texte,r.type_rec)!=EOF)
{
if(numero_list==r.num_list_elec)
{
i++;
}
}
fclose(f);
return i;
}

///////////////////////:








