#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
struct reclame
{
    int id ;
    int num_list_elec;
    int num_bureau;
    char date[70] ;
    char texte[300] ;
    char type_rec[200];
};
typedef struct reclame reclame;



struct liste
{
	int id_liste;
	char orientation[30];
	int id_tete;
	int id1;
	int id2;
	int id3;
	char date_ajout[30];
};
typedef struct liste liste;
//le type de  retour int c'est pour indiquer si la tache a été réalisée avec succés ou non// pour afficher des lsg plus tard exemple erreur d'ouverture de fichier, element introuvable
int ajouter_reclamation(char *, reclame );
int modifier_reclamation( char *, int, reclame );
int supprimer_reclamation(char *, int );
reclame chercher_reclamation(char *, int);
void afficher_reclamation(GtkWidget *liste) ;
void affiche_reclamation(GtkWidget *pliste);
int nbr_rec();
int nbr_rec_parlis(int numero_list);
#endif // POINT_H_INCLUDED

