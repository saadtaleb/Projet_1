#include <gtk/gtk.h>


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void afficher_reclamation(GtkWidget *liste) ;

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_typ_checkbutton8_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_id_checkbutton5_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nmb_checkbutton7_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nml_checkbutton6_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_ajouter_aller_ya_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_aller_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_aller_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_aller_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_confirmer_ya_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_ajouter_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_ya_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_ya_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_confirmer_ya_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifier_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_rec_ya_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_afficher_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_rec_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_stat_ya_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_confirmer_ya_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_supprimer_ya_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ref_retour_ya_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_stats_rec_ya_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nbrparl_stats_rec_ya_clicked (GtkButton       *button,
                                        gpointer         user_data);
