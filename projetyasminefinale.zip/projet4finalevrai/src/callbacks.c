#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclame.h"
#include <string.h>

int supp;
void delete(int supp, char msg[])
{	if(supp==1)
		strcpy(msg,"OUI");
	else if(supp==0)
		strcpy(msg,"NON");
}

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		supp=1;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	GtkWidget *f_supprimer;
	GtkWidget *f_reclamation;
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		{supp=2;
		f_supprimer = lookup_widget(togglebutton,"f_supprimer");
		gtk_widget_hide(f_supprimer);
		f_reclamation = create_f_reclamation();
		gtk_widget_show(f_reclamation);}
	
}





void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

//affichage dans un tableau ligne par ligne 
	int x ;
	GtkTreeIter iter ; 
	gint *id;
	gint *num_list_elec;
	gint *num_bureau;
	gchar *date;
	gchar *texte;
	gchar *type_rec;
	reclame r ;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model ,&iter , path)) 
	{
		//obtention des valeurs de la ligne selectionnées

		gtk_tree_model_get(GTK_LIST_STORE(model),&iter , 0 ,&id, 1 , &num_list_elec,2,&num_bureau,3,&date,4,&texte,5,&type_rec , -1);
		//copie des valeurs dans la variable e de type election pour le passer à la fonction de suppression
		r.id=*id          ;            //////////////////////////////////////////////////////////
		r.num_list_elec=*num_list_elec;
		r.num_bureau=*num_bureau;
		strcpy(r.date,date);
		strcpy(r.texte,texte);  
		strcpy(r.type_rec,type_rec);    /////////////////////////////////////////////////////
		//appel de la fonction de suppresion
		if(x=supprimer_reclamation("reclamation.txt",r.id)==1)
		// mise a jour de la l'affichage de la treeview
		afficher_reclamation(treeview);
	
	}



}



int T[3]={0,0,0,0};
void
on_typ_checkbutton8_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		T[3]=1;
}


void
on_id_checkbutton5_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		T[0]=1;
}


void
on_nmb_checkbutton7_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		T[2]=1;
}


void
on_nml_checkbutton6_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		T[1]=1;
}



void
on_ajouter_aller_ya_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_reclamation;
	GtkWidget *f_ajouter;
	f_reclamation = lookup_widget(button,"f_reclamation");
	gtk_widget_hide(f_reclamation);
	f_ajouter = create_f_ajouter();
	gtk_widget_show(f_ajouter);
}


void
on_modifier_aller_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_reclamation;
	GtkWidget *f_modifier;
	f_reclamation = lookup_widget(button,"f_reclamation");
	gtk_widget_hide(f_reclamation);
	f_modifier = create_f_modifier();
	gtk_widget_show(f_modifier);
}


void
on_afficher_aller_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_reclamation; 
	GtkWidget *f_afficher;
	GtkWidget *treeview1;

	f_reclamation=lookup_widget(button,"f_reclamation");

	gtk_widget_destroy(f_reclamation);
	f_afficher=lookup_widget(button,"f_afficher");
	f_afficher=create_f_afficher();

	gtk_widget_show(f_afficher);

	treeview1=lookup_widget(f_afficher,"treeview1");

	afficher_reclamation(treeview1) ;
}


void
on_supprimer_aller_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_reclamation;
	GtkWidget *f_supprimer;
	f_reclamation = lookup_widget(button,"f_reclamation");
	gtk_widget_hide(f_reclamation);
	f_supprimer = create_f_supprimer();
	gtk_widget_show(f_supprimer);
}


void
on_ajouter_confirmer_ya_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
int d ; char t[50]; int x;
	char* ch=(char *) malloc(500);
	strcpy(ch,"");
	char* sh=(char *) malloc(500);
	strcpy(sh,"");
	reclame r,v; 
	GtkWidget *entree1, *entry2, *entry3, *entry8, *spinbutton1 , *spinbutton2,*sortie_id, *sortie_typ, *label34 , *info,*inf;
	GtkWidget *f_ajouter; 
 //les 3 chars ==> id / texte de rec/type de rec
	entree1 = lookup_widget(button,"entree1"); //id
	entry2 = lookup_widget(button,"entry2"); //tpe_rec           
	entry3 = lookup_widget(button,"entry3"); //texte
	entry8 = lookup_widget(button,"entry8"); //date
	//sortie_id = lookup_widget(objet,"sortie_id"); //controle de saisie sur l'id
	//sortie_typ = lookup_widget(objet,"sortie_typ"); //controle de saisie sur le type et le texte de reclamation
	label34 = lookup_widget(button,"sortie");//sortie de confirmation ou d'echec	                
	if (((strcmp(gtk_entry_get_text(GTK_ENTRY(entree1)),""))==0) || (strlen(gtk_entry_get_text(GTK_ENTRY(entree1)))!=4))//controle de saisie sur l'id	
	strcat(ch,"veuillez saisir l'ID correctement\n");
	if ((strcmp(gtk_entry_get_text(GTK_ENTRY(entry2)),""))==0)//controle de saisie sur le type
	strcat(ch,"veuillez saisir le type de la reclamation\n");
	if ((strcmp(gtk_entry_get_text(GTK_ENTRY(entry3)),"")==0))//controle de saisie sur le texte
	strcat(ch,"veuillez saisir le texte de la reclamation\n");
	if(strcmp(ch,"")==0){
	strcpy(t,gtk_entry_get_text(GTK_ENTRY(entree1)));
	d=atoi(t);
	if(d==0){
	strcat(sh,"ID invalide\n");
	inf=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,sh);
		switch(gtk_dialog_run(GTK_DIALOG(inf)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(inf);
			break;
		}}
	else{
	r.id=d; 
	strcpy(r.texte,gtk_entry_get_text(GTK_ENTRY(entry3))); 

// id chaine en int 
 	strcpy(r.type_rec,gtk_entry_get_text(GTK_ENTRY(entry2))); 
	strcpy(r.date,gtk_entry_get_text(GTK_ENTRY(entry8)));

	spinbutton1=lookup_widget(button,"spinbutton1"); //numero_liste_rec
	spinbutton2=lookup_widget(button,"spinbutton2");//num_bureau_de_vote
	
	r.num_list_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1)); 
	r.num_bureau=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2)); 

	v=chercher_reclamation("reclamation.txt",d);
	if(v.id!=-1){
		gtk_label_set_text(GTK_LABEL(label34),"ID DÉJÀ EXISTE ");}
	else  {
	x=ajouter_reclamation("reclamation.txt", r);
	gtk_label_set_text(GTK_LABEL(label34),"AJOUT DE LA RECLAMATION AVEC SUCCES ");
	}}}
else{
		info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
		switch(gtk_dialog_run(GTK_DIALOG(info)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(info);
			break;
		}
	}





}


void
on_retour_ajouter_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_ajouter ;
	GtkWidget *f_reclamation;
	f_ajouter = lookup_widget(button,"f_ajouter");
	gtk_widget_hide(f_ajouter);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}

int t;
void
on_confirmer_ya_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char p[50];int i,j; reclame r,v; char* ch=(char *) malloc(500);
	char* sh=(char *) malloc(500);
	strcpy(ch,"");
	strcpy(sh,"");
	GtkWidget *entry4, *label38, *info, *inf;
	GtkWidget *f_modifier;
	entry4=lookup_widget(button,"entry4"); //id de la reclamation qui tu veux la changer
	label38=lookup_widget(button,"mod"); //un label pour l'echec de trouver l'id dans le fichier
	if (((strcmp(gtk_entry_get_text(GTK_ENTRY(entry4)),""))==0) || (strlen(gtk_entry_get_text(GTK_ENTRY(entry4)))!=4)){//controle de saisie
	strcat(ch,"ID invalide\n");
	info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
		switch(gtk_dialog_run(GTK_DIALOG(info)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(info);
			break;
		}}
	else //if(strcmp(ch,"")==0){
{
	strcpy(p,gtk_entry_get_text(GTK_ENTRY(entry4)));
	i=atoi(p);
	if(i==0){
	strcat(sh,"ID invalide\n");
	inf=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,sh);
		switch(gtk_dialog_run(GTK_DIALOG(inf)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(inf);
			break;
		}}
	else{
	
	r.id=i;
	/*FILE * f=fopen("reclamation.txt", "r");
	if(f!=NULL)
    	{
        	while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau, r.date, r.texte, r.type_rec)!=EOF)
        	{
            		if(r.id== i)
                		t=1;
            	else
                	gtk_label_set_text(GTK_LABEL(label38),"ECHEC DE TROUVER CETTE RECLAMATION ");	
        	}
    	}
    	fclose(f);*/
	v=chercher_reclamation("reclamation.txt",i);
	if(v.id!=-1){
		t=1;
		gtk_label_set_text(GTK_LABEL(label38),"SUCCES DE TROUVER CETTE RECLAMATION ");
		j=supprimer_reclamation("reclamation.txt",i);}
	else 
		gtk_label_set_text(GTK_LABEL(label38),"ECHEC DE TROUVER CETTE RECLAMATION ");	} 


}




}


void
on_annuler_ya_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_modifier ;
	GtkWidget *f_reclamation;
	f_modifier = lookup_widget(button,"f_modifier");
	gtk_widget_hide(f_modifier);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}


void
on_modifier_confirmer_ya_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
int d,x,tr,t=1; char w[50]; reclame r,v;char* ch=(char *) malloc(500);
	strcpy(ch,"");
	char* sh=(char *) malloc(500);
	strcpy(sh,"");
	GtkWidget *f_modifier ;
	GtkWidget *entry10, *entry9, *entry5, *entry6, *spinbutton6, *spinbutton7, *label27 , *nv_id ,*info, *inf, *nv_typ;
	entry10 = lookup_widget(button,"entry10"); //nouveau id
	entry5 = lookup_widget(button,"entry5"); //tpe_rec
	entry6 = lookup_widget(button,"entry6"); //texte
	entry9 = lookup_widget(button,"entry9"); //date
	label27 = lookup_widget(button,"ys"); //sortie de confirmation ou d'echec
	nv_id = lookup_widget(button,"nv_id"); //controle de saisie sur l'id
	nv_typ = lookup_widget(button,"nv_typ"); //controle de saisie sur le type et le texte de reclamation 
	if (((strcmp(gtk_entry_get_text(GTK_ENTRY(entry10)),""))==0) || (strlen(gtk_entry_get_text(GTK_ENTRY(entry10)))!=4))//controle de saisie sur l'id	
	strcat(ch,"veuillez saisir le nouveau ID correctement\n");
	if ((strcmp(gtk_entry_get_text(GTK_ENTRY(entry5)),""))==0)//controle de saisie sur le type
	strcat(ch,"veuillez saisir le type de la nouvelle reclamation\n");
	if ((strcmp(gtk_entry_get_text(GTK_ENTRY(entry6)),"")==0))//controle de saisie sur le texte           
	strcat(ch,"veuillez saisir le texte de la nouvelle reclamation\n");
	if(strcmp(ch,"")==0){
	strcpy(w,gtk_entry_get_text(GTK_ENTRY(entry10)));	
														 
	d=atoi(w);
	
	if(d==0){
	strcat(sh,"ID invalide\n");
	inf=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,sh);
		switch(gtk_dialog_run(GTK_DIALOG(inf)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(inf);
			break;
		}}
	else{
	v.id=d; 

	strcpy(v.texte,gtk_entry_get_text(GTK_ENTRY(entry6))); 
 	strcpy(v.type_rec,gtk_entry_get_text(GTK_ENTRY(entry5))); 
	strcpy(v.date,gtk_entry_get_text(GTK_ENTRY(entry9)));

	spinbutton6=lookup_widget(button,"spinbutton6"); //numero_liste_rec
	spinbutton7=lookup_widget(button,"spinbutton7");//num_bureau_de_vote
	
	v.num_list_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton6));
	v.num_bureau=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton7)); 
	x=ajouter_reclamation("reclamation.txt",v);
		gtk_label_set_text(GTK_LABEL(label27),"MODIFICATION AVEC SUCCES");
	}}

else{
		info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
		switch(gtk_dialog_run(GTK_DIALOG(info)))
		{
			case GTK_RESPONSE_OK:
			gtk_widget_destroy(info);
			break;
		}}

}


void
on_retour_modifier_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_modifier ;
	GtkWidget *f_reclamation;
	f_modifier = lookup_widget(button,"f_modifier");
	gtk_widget_hide(f_modifier);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}


void
on_chercher_rec_ya_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char q[50]; int i;
	GtkWidget *entry11;//id
	GtkWidget *entry12;//type
	GtkWidget *spinbutton8;//numlist
	GtkWidget *spinbutton9;//numbureau
	reclame test,r;
	if(T[0]==1 && T[1]==0 && T[2]==0 && T[3]==0)
		{
		entry11=lookup_widget(button,"entry11");//id
		strcpy(q,gtk_entry_get_text(GTK_ENTRY(entry11)));
		i=atoi(q);
		test.id=i;

		FILE *f=fopen("reclamation.txt","r");
		FILE *f1=fopen("recherche.txt","w");
		while(fscanf(f,"%d %d %d %s %s %s\n",&r.id,&r.num_list_elec,&r.num_bureau,r.date,r.type_rec,r.texte)!=EOF)
		{
			if(test.id==r.id)
			{
				fprintf(f1,"%d %d %d %s %s %s\n",r.id,r.num_list_elec,r.num_bureau,r.date,r.type_rec,r.texte);
			}
		}
		fclose(f);
		fclose(f1);
		GtkWidget *supprimer, *liste, *treeview ;

		supprimer=lookup_widget(button,"f_afficher");
		gtk_widget_destroy(supprimer);
		liste=lookup_widget(button,"f_afficher");
		liste=create_f_afficher();
		gtk_widget_show(liste);
		treeview=lookup_widget(liste,"treeview1");
		affiche_reclamation(treeview);

		T[0]=0;

		}
	else if (T[1]==1 && T[0]==0 && T[2]==0 && T[3]==0)
	{
		spinbutton8=lookup_widget(GTK_WIDGET(button),"spinbutton8");
		test.num_list_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton8)); 
		FILE * f=fopen("reclamation.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %d %d %s %s %s\n",&r.id ,&r.num_list_elec ,&r.num_bureau ,r.date ,r.texte ,r.type_rec)!=EOF){
			if(test.num_list_elec==r.num_list_elec){
				fprintf(f1,"%d %d %d %s %s %s \n",r.id,r.num_list_elec,r.num_bureau,r.date,r.type_rec,r.texte);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(button,"f_afficher");

gtk_widget_destroy(supprimer);

liste=lookup_widget(button,"f_afficher");

liste=create_f_afficher();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_reclamation(treeview);

T[1]=0;

		}
	else if (T[2]==0 && T[0]==0 && T[1]==0 && T[3]==1)
	{
		entry12=lookup_widget(button,"entry12");
		strcpy(test.type_rec,gtk_entry_get_text(GTK_ENTRY(entry12)));
		FILE * f=fopen("reclamation.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %d %d %s %s %s \n",&r.id,&r.num_list_elec,&r.num_bureau,r.date,r.type_rec,r.texte)!=EOF){
			if (strcmp(test.type_rec,r.type_rec)==0){
				fprintf(f1,"%d %d %d %s %s %s \n",r.id,r.num_list_elec,r.num_bureau,r.date,r.type_rec,r.texte);
			}
		}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(button,"f_afficher");

gtk_widget_destroy(supprimer);

liste=lookup_widget(button,"f_afficher");

liste=create_f_afficher();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_reclamation(treeview);

T[3]=0;

		}
		else if (T[3]==0 && T[0]==0 && T[1]==0 && T[2]==1)
		{
		spinbutton9=lookup_widget(button,"spinbutton9");
		test.num_bureau=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton9)); 
		FILE * f=fopen("reclamation.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %d %d %s %s %s\n",&r.id ,&r.num_list_elec ,&r.num_bureau ,r.date ,r.texte ,r.type_rec)!=EOF){
			if(test.num_bureau==r.num_bureau){
				fprintf(f1,"%d %d %d %s %s %s \n",r.id,r.num_list_elec,r.num_bureau,r.date,r.type_rec,r.texte);
			}
		}
fclose(f);
fclose(f1);
GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(button,"f_afficher");

gtk_widget_destroy(supprimer);

liste=lookup_widget(button,"f_afficher");

liste=create_f_afficher();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_reclamation(treeview);

T[2]=0;
}
	else {
		GtkWidget *supprimer, *liste, *treeview ;

		supprimer=lookup_widget(button,"f_afficher");

		gtk_widget_destroy(supprimer);

		liste=lookup_widget(button,"f_afficher");

		liste=create_f_afficher();

		gtk_widget_show(liste);

		treeview=lookup_widget(liste,"treeview1");

		affiche_reclamation(treeview);

		T[0]=0;

		T[1]=0;

		T[2]=0;
		T[3]=0;

	}
}


void
on_retour_afficher_ya_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_afficher ;
	GtkWidget *f_reclamation;
	f_afficher = lookup_widget(button,"f_afficher");
	gtk_widget_hide(f_afficher);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}


void
on_actualiser_rec_ya_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_afficher ,*w1;
	GtkWidget *treeview1 ; 


	w1 = lookup_widget(button,"f_afficher");
	f_afficher=create_f_afficher();

	gtk_widget_show(f_afficher);

	gtk_widget_hide (w1);
	treeview1=lookup_widget(f_afficher,"treeview1");

	//vider(treeview1);
	afficher_reclamation(treeview1);
}


void
on_stat_ya_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_reclamation;
	GtkWidget *f_stat;
	f_reclamation = lookup_widget(button,"f_reclamation");
	gtk_widget_hide(f_reclamation);
	f_stat = create_f_stat();
	gtk_widget_show(f_stat);
}


void
on_supprimer_confirmer_ya_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	int s,z; char i[50];int supp=1;
	GtkWidget *f_supprimer;
	GtkWidget *entry7, *label37;
	reclame r;
	entry7 = lookup_widget(button,"entry7"); //id
	label37 = lookup_widget(button,"let");
	
	strcpy(i,gtk_entry_get_text(GTK_ENTRY(entry7))); 		                        								 
	s=atoi(i);
	r.id=s; 
	z=supprimer_reclamation("reclamation.txt",s);
	if (z==1)
		gtk_label_set_text(GTK_LABEL(label37),"Suppression avec succes");
	else 
		gtk_label_set_text(GTK_LABEL(label37),"ECHEC");

}


void
on_retour_supprimer_ya_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_supprimer;
	GtkWidget *f_reclamation;
	f_supprimer = lookup_widget(button,"f_supprimer");
	gtk_widget_hide(f_supprimer);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}


void
on_ref_retour_ya_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *f_stat;
	GtkWidget *f_reclamation;
	f_stat = lookup_widget(button,"f_stat");
	gtk_widget_hide(f_stat);
	f_reclamation = create_f_reclamation();
	gtk_widget_show(f_reclamation);
}


void
on_stats_rec_ya_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *NBr,*l;
int k;
	
 char ch[40];
 NBr =lookup_widget(button, "stats_rec" );
 k=nbr_rec();

 l=lookup_widget(button,"label_nbr_rec");
 
sprintf(ch,"Le nombre de reclamation est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch); 
}


void
on_button_nbrparl_stats_rec_ya_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget *NBr,*l;
int k;
int liste;
	
 char ch[40];
 input = lookup_widget(button, "entry_nbrliste_rec") ;
liste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
 NBr =lookup_widget(button, "button_nbrparl_stats_rec" );
 k=nbr_rec_parlis(liste);

 l=lookup_widget(button,"label_nbrliste_rec");
 
sprintf(ch,"Cette liste est reclamée %d fois",k);
 gtk_label_set_text(GTK_LABEL(l),ch); 
}

