#ifndef OBSERVATEUR_H_INCLUDED
#define OBSERVATEUR_H_INCLUDED
#include<gtk/gtk.h>

typedef struct {
int jour;
int mois;
int annee;
}date;

typedef struct {
int id ;
char nom[20];
char prenom[20];
char nationalite[20];
char profession[20];
char genre[20];
date date_naissance;
}observateur;

int ajouter(observateur o , char filename []);
int modifier(int id, observateur nouv, char * filename);
int supprimer(int id, char * filename);
observateur chercher(int id, char * filename);
void afficher_observateur(GtkWidget *pListView);
void affiche_observateur(GtkWidget *pListView);
int nbobserver(char * filename);
void trier(char * Filename);

#endif 

