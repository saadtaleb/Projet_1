#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "observateur.h"
#include <string.h>


void
on_Ajouterobservateur_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter, *liste;

ajouter=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

gtk_widget_destroy(ajouter);

liste=lookup_widget(GTK_WIDGET(button),"Ajouter_observateur");

liste=create_Ajouter_observateur();

gtk_widget_show(liste);
}


void
on_Modifierobservateur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter,*liste,*treeview;

ajouter=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

gtk_widget_destroy(ajouter);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);
}


void
on_Deconnecterobservateur_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste ;

modifier=lookup_widget(GTK_WIDGET(button),"Ajouter_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

liste=create_Gestion_observateur();

gtk_widget_show(liste);
}


int profession;
int genre;

void professions (int profession ,char prof[]){
if (profession == 1)
	strcpy(prof,"journaliste");
else if (profession == 2)
	strcpy(prof,"observateur");
else if (profession == 3)
	strcpy(prof,"interprete");
else if (profession == 4)
	strcpy(prof,"hote");

}
void genres (int genre ,char gnr[]){
if (genre == 0)
	strcpy(gnr,"homme");
else if (genre == 5)
	strcpy(gnr,"femme");
}

void
on_journaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		profession=1;
}


void
on_observateur_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		profession=2;
}


void
on_interprete_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		profession=3;
}


void
on_hote_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		profession=4;
}


void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		genre=0;
}


void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		genre=5;
}


void
on_Ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id, *nom, *prenom, *nationalite, *jour, *mois, *annee, *sortie , *info, *inf;
char* ch = (char *) malloc(500);
char* sh = (char *) malloc(500);
strcpy(ch,"");
strcpy(sh,"");
char ide[20];
int iden;
observateur o,s;

id=lookup_widget(GTK_WIDGET(button),"id");
nom=lookup_widget(GTK_WIDGET(button),"nom");
prenom=lookup_widget(GTK_WIDGET(button),"prenom");
jour=lookup_widget(GTK_WIDGET(button),"jour");
mois=lookup_widget(GTK_WIDGET(button),"mois");
annee=lookup_widget(GTK_WIDGET(button),"annee");
nationalite=lookup_widget(GTK_WIDGET(button),"nationalite");
sortie=lookup_widget(GTK_WIDGET(button),"idexi");

o.date_naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
o.date_naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
o.date_naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


if(     (strcmp(gtk_entry_get_text(GTK_ENTRY(id)),"")==0) || (strlen(gtk_entry_get_text(GTK_ENTRY(id)))!=8)                                  )
strcat(ch,"ID invalide\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(nom)),"")==0)
strcat(ch,"Nom invalide\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(prenom)),"")==0)
strcat(ch,"Prenom invalide\n");
if(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(nationalite)),"")==0)
strcat(ch,"Nationalité invalide\n");


if(strcmp(ch,"")==0){




strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nationalite)));


strcpy(ide,gtk_entry_get_text(GTK_ENTRY(id)));
iden= atoi(ide);
if(iden==0){
strcat(sh,"ID invalide\n");
inf=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,sh);
	switch(gtk_dialog_run(GTK_DIALOG(inf)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(inf);
	break;
	}}
else {
o.id=iden;

strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
professions(profession,o.profession);
genres(genre,o.genre);
s=chercher(iden,"observateur.txt");

if (s.id!=-1)
	gtk_label_set_text(GTK_LABEL(sortie),"ID existant !");
else {

int x=ajouter(o,"observateur.txt");
gtk_label_set_text(GTK_LABEL(sortie),"Ajouté avec succès !");

	}

}}

else{
info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(info)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(info);
	break;
	}
}}

void
on_Deconnecterliste_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_retour2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste ;

modifier=lookup_widget(GTK_WIDGET(button),"Ajouter_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

liste=create_Gestion_observateur();

gtk_widget_show(liste);
}


void
on_deconnecterlisteobs_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}



int idmod;

void
on_Modifierlis_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id, *sortie;
char ide[20];
observateur o;

id=lookup_widget(GTK_WIDGET(button),"idmodsupentry");
sortie=lookup_widget(GTK_WIDGET(button),"label969");
strcpy(ide,gtk_entry_get_text(GTK_ENTRY(id)));
idmod= atoi(ide);

o=chercher(idmod,"observateur.txt");

if (o.id==-1)
	gtk_label_set_text(GTK_LABEL(sortie),"ID introuvable!");
else{
	GtkWidget *modifier, *liste;

	modifier=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

	gtk_widget_destroy(modifier);

	liste=lookup_widget(GTK_WIDGET(button),"Modifier_observateur");

	liste=create_Modifier_observateur();

	gtk_widget_show(liste);

	}
}


void
on_Supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ID, *sortie;
char id[20];
int iden;
observateur o;

ID=lookup_widget(GTK_WIDGET(button),"idmodsupentry");
sortie=lookup_widget(GTK_WIDGET(button),"label969");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(ID)));
iden= atoi(id);

o=chercher(iden,"observateur.txt");

if (o.id==-1)
	gtk_label_set_text(GTK_LABEL(sortie),"ID introuvable!");
else{
	int x=supprimer(iden,"observateur.txt");

	GtkWidget *supprimer, *liste, *treeview ;

	supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

	gtk_widget_destroy(supprimer);

	liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

	liste=create_Liste_observateurs();

	gtk_widget_show(liste);

	treeview=lookup_widget(liste,"treeview1");

	afficher_observateur(treeview);
	}
}


int T[4]={0,0,0,0};


void
on_Recherchercrit_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char ide[20];
int iden;
GtkWidget *genre, *nationalite, *profession,*id;
observateur test,o;
	
	if (T[0]==1 && T[1]==0 && T[2]==0 && T[3]==0){
		genre=lookup_widget(GTK_WIDGET(button),"lgenre");
		strcpy(test.genre,gtk_entry_get_text(GTK_ENTRY(genre)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.genre,o.genre)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[0]=0;

		}
	else if (T[1]==1 && T[0]==0 && T[2]==0 && T[3]==0){
		nationalite=lookup_widget(GTK_WIDGET(button),"lnationalite");
		strcpy(test.nationalite,gtk_entry_get_text(GTK_ENTRY(nationalite)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.nationalite,o.nationalite)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[1]=0;

		}
	else if (T[2]==1 && T[0]==0 && T[1]==0 && T[2]==0){
		profession=lookup_widget(GTK_WIDGET(button),"lprofession");
		strcpy(test.profession,gtk_entry_get_text(GTK_ENTRY(profession)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.profession,o.profession)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[2]=0;

		}












else if (T[3]==1 && T[0]==0 && T[1]==0 && T[2]==0){
		id=lookup_widget(GTK_WIDGET(button),"lid");
		strcpy(ide,gtk_entry_get_text(GTK_ENTRY(id)));
		test.id=atoi(ide);
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (test.id==o.id){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[3]=0;

		}






	else {
		GtkWidget *supprimer, *liste, *treeview ;

		supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

		gtk_widget_destroy(supprimer);

		liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

		liste=create_Liste_observateurs();

		gtk_widget_show(liste);

		treeview=lookup_widget(liste,"treeview1");

		afficher_observateur(treeview);

		T[0]=0;

		T[1]=0;

		T[2]=0;

		T[3]=0;

	}
}


void
on_Refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);

}


void
on_retour3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste ;

modifier=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

liste=create_Gestion_observateur();

gtk_widget_show(liste);
}


void
on_mjounaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			profession=1;
}


void
on_mobservateur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			profession=2;
}


void
on_minterprete_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			profession=3;
}


void
on_mhote_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			profession=4;
}


void
on_mhomme_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			genre=0;
}


void
on_mfemme_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
			genre=5;
}


void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom, *Prenom, *Nationalite, *jour, *mois, *annee , *info;
char id[20];
int iden;
observateur nouv; 
char* ch = (char *) malloc(500);
strcpy(ch,"");
Nom=lookup_widget(GTK_WIDGET(button),"mnom");
Prenom=lookup_widget(GTK_WIDGET(button),"mprenom");
jour=lookup_widget(GTK_WIDGET(button),"mjour");
mois=lookup_widget(GTK_WIDGET(button),"mmois");
annee=lookup_widget(GTK_WIDGET(button),"mannee");
Nationalite=lookup_widget(GTK_WIDGET(button),"mnationalite");

nouv.date_naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
nouv.date_naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
nouv.date_naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));



nouv.id=idmod;
if(strcmp(gtk_entry_get_text(GTK_ENTRY(Nom)),"")==0)
strcat(ch,"Nom invalide\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(Prenom)),"")==0)
strcat(ch,"Prenom invalide\n");
if(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nationalite)),"")==0)
strcat(ch,"Nationalité invalide\n");

if(strcmp(ch,"")==0){





strcpy(nouv.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(nouv.prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(nouv.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nationalite)));
professions(profession,nouv.profession);
genres(genre,nouv.genre);

int x=modifier(idmod, nouv, "observateur.txt");

GtkWidget *modifier, *liste, *treeview;

modifier=lookup_widget(GTK_WIDGET(button),"Modifier_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);}
else{
info=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(info)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(info);
	break;
	}

}}


void
on_retour4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste, *treeview ;

modifier=lookup_widget(GTK_WIDGET(button),"Modifier_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);
}


void
on_checkgenre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		T[0]=1;
}


void
on_checknationalite_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		T[1]=1;
}


void
on_checkprofession_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		T[2]=1;
}


void
on_checkid_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if (gtk_toggle_button_get_active(togglebutton))
		T[3]=1;

}


void on_Modifierlisob_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste,*treeview ;

modifier=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();


gtk_widget_show(liste);



treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);


}
void
on_Modifierliste_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter, *liste, *treeview;

ajouter=lookup_widget(GTK_WIDGET(button),"Ajouter_observateur");

gtk_widget_destroy(ajouter);

liste=lookup_widget(GTK_WIDGET(button),"Liste_observateurs");

liste=create_Liste_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);
}

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *modifier, *liste,*treeview ;

modifier=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();


gtk_widget_show(liste);



treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);


}



int tp;
char obk[30];

void on_nbrobs_clicked                     (GtkButton       *button,
                                                   gpointer         user_data)
{
GtkWidget *supprimer, *liste, *treeview,*sortie;



sortie= lookup_widget(button, "label447") ;
tp=nbobserver("observateur.txt");
sprintf(obk,"%d",tp);
gtk_label_set_text(GTK_LABEL(sortie),obk);




}





void
on_triobs_clicked                     (GtkButton       *button,
                                              gpointer         user_data)
{
GtkWidget *supprimer, *liste, *treeview ;




trier("observateur.txt");
supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);



}

void
on_Refresh2_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

afficher_observateur(treeview);
}




void
on_Recherchercrit2_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char ide[20];
int iden;
GtkWidget *genre, *nationalite, *profession,*id;
observateur test,o;
	
	if (T[0]==1 && T[1]==0 && T[2]==0 && T[3]==0){
		genre=lookup_widget(GTK_WIDGET(button),"lgenre");
		strcpy(test.genre,gtk_entry_get_text(GTK_ENTRY(genre)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.genre,o.genre)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[0]=0;

		}
	else if (T[1]==1 && T[0]==0 && T[2]==0 && T[3]==0){
		nationalite=lookup_widget(GTK_WIDGET(button),"lnationalite");
		strcpy(test.nationalite,gtk_entry_get_text(GTK_ENTRY(nationalite)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.nationalite,o.nationalite)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[1]=0;

		}
	else if (T[2]==1 && T[0]==0 && T[1]==0 && T[2]==0){
		profession=lookup_widget(GTK_WIDGET(button),"lprofession");
		strcpy(test.profession,gtk_entry_get_text(GTK_ENTRY(profession)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.profession,o.profession)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[2]=0;

		}






else if (T[3]==1 && T[0]==0 && T[1]==0 && T[2]==0){
		id=lookup_widget(GTK_WIDGET(button),"lid");
		strcpy(ide,gtk_entry_get_text(GTK_ENTRY(id)));
		test.id=atoi(ide);
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (test.id==o.id){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview ;

supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

liste=create_Afficher_observateurs();

gtk_widget_show(liste);

treeview=lookup_widget(liste,"treeview1");

affiche_observateur(treeview);

T[3]=0;

		}






	else {
		GtkWidget *supprimer, *liste, *treeview ;

		supprimer=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

		gtk_widget_destroy(supprimer);

		liste=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

		liste=create_Afficher_observateurs();

		gtk_widget_show(liste);

		treeview=lookup_widget(liste,"treeview1");

		afficher_observateur(treeview);

		T[0]=0;

		T[1]=0;

		T[2]=0;

		T[3]=0;

	}


}


void
on_retour8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier, *liste ;

modifier=lookup_widget(GTK_WIDGET(button),"Afficher_observateurs");

gtk_widget_destroy(modifier);

liste=lookup_widget(GTK_WIDGET(button),"Gestion_observateur");

liste=create_Gestion_observateur();

gtk_widget_show(liste);

}

