#include <gtk/gtk.h>


void
on_Deconnecterobservateur_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouterobservateur_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierlisob_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_hote_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_observateur_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_interprete_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_journaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierlis_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Recherchercrit_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkgenre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checknationalite_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkprofession_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_mjounaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mobservateur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_minterprete_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mhote_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mhomme_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mfemme_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_nbrobs_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_triobs_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Refresh2_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkid_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkid_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Recherchercrit2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
