#include "observateur.h"
#include<stdio.h>
#include<string.h>
#include<gtk/gtk.h>

int ajouter(observateur o , char filename [])
{
    FILE * f=fopen(filename, "a");
    if(f!=NULL)
    {
        fprintf(f,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
        fclose(f);
        return 1;
    }
    else 
	return 0;
}

int modifier(int id, observateur nouv, char * filename)
{
observateur o ;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)
{
if(o.id!=id)
        fprintf(f2,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
else

  fprintf(f2,"%d %s %s %s %s %s %d %d %d \n",nouv.id,nouv.nom,nouv.prenom,nouv.nationalite,nouv.profession,nouv.genre,nouv.date_naissance.jour,nouv.date_naissance.mois,nouv.date_naissance.annee);

}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
return 1;
    }
  
}

int supprimer(int id, char * filename)
{
observateur o;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)
{
if(o.id!=id)
        fprintf(f2,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);

}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
return 1;
    }
}

observateur chercher(int id, char * filename)
{
observateur o; int tr=0;
    FILE * f=fopen(filename, "r");
 if(f!=NULL )
    {
while(tr==0 && fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)
{if(id==o.id)
tr=1;
}
}
if(tr==0)
o.id=-1;
return o;

}


enum {
ID_OBSERVATEUR,
NOM,
PRENOM,
NATIONALITE,
PROFESSION,
GENRE,
DATE_NAISSANCE,
N_COLUMN,
};





void afficher_observateur(GtkWidget *pListView)

{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
observateur o;
int id;
char nom[20];
char prenom[20];
char nationalite[20];
char profession[20];
char genre[20];
date date_naissance;
char var1[20],var2[20],var3[20],var4[20],var5[20];

pListStore=NULL;

FILE *f;

pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id",pCellRenderer,"text", ID_OBSERVATEUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nom",pCellRenderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("prenom",pCellRenderer,"text", PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nationalite",pCellRenderer,"text", NATIONALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("profession",pCellRenderer,"text", PROFESSION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("genre",pCellRenderer,"text", GENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("date_naissance",pCellRenderer,"text", DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


f=fopen("observateur.txt","r");

if (f==NULL){return;}

else{
f=fopen("observateur.txt","a+");

while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)

{

sprintf(var1,"%d",o.id);

sprintf(var2,"%d / %d / %d",o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,ID_OBSERVATEUR,var1,NOM,o.nom,PRENOM,o.prenom,NATIONALITE,o.nationalite,PROFESSION,o.profession,GENRE,o.genre,DATE_NAISSANCE,var2,-1);

}

fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}

}


void affiche_observateur(GtkWidget *pListView)

{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
observateur o;
int id;
char nom[20];
char prenom[20];
char nationalite[20];
char profession[20];
char genre[20];
date date_naissance;
char var1[20],var2[20],var3[20],var4[20],var5[20];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id",pCellRenderer,"text", ID_OBSERVATEUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nom",pCellRenderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("prenom",pCellRenderer,"text", PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nationalite",pCellRenderer,"text", NATIONALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("profession",pCellRenderer,"text", PROFESSION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("genre",pCellRenderer,"text", GENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("date_naissance",pCellRenderer,"text", DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("recherche.txt","r");
if (f==NULL){return;}

else{
f=fopen("recherche.txt","a+");

while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)

{

sprintf(var1,"%d",o.id);

sprintf(var2,"%d / %d / %d",o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,ID_OBSERVATEUR,var1,NOM,o.nom,PRENOM,o.prenom,NATIONALITE,o.nationalite,PROFESSION,o.profession,GENRE,o.genre,DATE_NAISSANCE,var2,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}

}







int nbobserver( char * filename)
{
int i=0;
observateur o;
    FILE * f=fopen( "observateur.txt", "r");
   
    if(f==NULL)
       return 0;
else
    {
while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF)
{
i++;

}
        fclose(f);
        return i ;
    }
  
}


void trier(char * Filename){
int i=0,k=0,j=0,l=0,iden,ok=1,m=0;
observateur tab[100];
observateur o,aux;
    FILE * f=fopen( "observateur.txt", "r");
    FILE * f2 =fopen("aux.txt", "w");
   
   
	if(f==NULL)
		printf("impossible d'ouvrir le fichier");
	else{
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			tab[i]=o;
			i++;	}
		
		while (l<i){
			for(k=0;k<i-1;k++){
				if (strcmp(tab[k].nom,tab[k+1].nom)>0){
					aux=tab[k+1];
					tab[k+1]=tab[k];
					tab[k]=aux;	}
					}
			l++;	}
		while (j<i){
			fprintf(f2,"%d %s %s %s %s %s %d %d %d\n",tab[j].id,tab[j].nom,tab[j].prenom,tab[j].nationalite,tab[j].profession,tab[j].genre,tab[j].date_naissance.jour,tab[j].date_naissance.mois,tab[j].date_naissance.annee);
			j++; 	}


		fclose(f);
        	fclose(f2);
		
remove(Filename);
rename("aux.txt", Filename);
}
}
